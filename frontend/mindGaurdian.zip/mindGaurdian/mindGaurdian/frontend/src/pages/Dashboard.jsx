import { useState } from "react";
import BreathingGame from "../components/games/BreathingGame";

export default function Dashboard() {
  const mood = localStorage.getItem("userMood");
  const [showGame, setShowGame] = useState(false);

  return (
    <div style={styles.wrapper}>
      <h1 style={styles.title}>
  Good Morning 👋 <span style={{ color: "#5DB075" }}>
    {localStorage.getItem("userName") || "Friend"}
  </span>
</h1>

      <div style={styles.card}>
        <p style={styles.score}>Daily Wellness Score</p>
        <h2 style={styles.big}>{mood === "Stressed" ? "58" : "78"} / 100</h2>
        <p style={styles.tag}>{mood} day expected</p>
      </div>

      <div style={styles.section}>
        <h3>Today’s Gentle Suggestions</h3>
        <div style={styles.grid}>
  {mood === "Stressed" && (
  <div style={styles.box} onClick={() => setShowGame(true)}>
    3-min breathing
  </div>
)}

  {mood === "Tired" && <div style={styles.box}>5-min walk</div>}
  {mood === "Okay" && <div style={styles.box}>Focus booster</div>}
  {mood === "Calm" && <div style={styles.box}>Gratitude garden</div>}
</div>

      </div>
      {showGame && <BreathingGame onClose={() => setShowGame(false)} />}
    </div>
  );
}

const styles = {
  wrapper: {
    minHeight: "100vh",
    padding: 24,
    background: "linear-gradient(to bottom, #101615, #1c1f1e)",
    color: "#fff",
    fontFamily: "system-ui",
  },

  title: {
    fontSize: 28,
    fontWeight: 600,
    marginBottom: 20,
  },

  card: {
    background: "#ffffff",
    borderRadius: 22,
    padding: 26,
    color: "#111",
    maxWidth: 420,
    boxShadow: "0 20px 40px rgba(0,0,0,.35)",
  },

  score: {
    color: "#777",
    fontSize: 14,
  },

  big: {
    fontSize: 44,
    margin: "6px 0",
    fontWeight: 600,
  },

  tag: {
    color: "#5DB075",
    fontWeight: 500,
    marginTop: 4,
  },

  section: {
    marginTop: 40,
    maxWidth: 420,
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 14,
    marginTop: 16,
  },

  box: {
    background: "#ffffff",
    color: "#111",
    padding: 16,
    borderRadius: 16,
    textAlign: "center",
    fontWeight: 500,
    boxShadow: "0 6px 16px rgba(0,0,0,.25)",
    cursor: "pointer",
  },
};
