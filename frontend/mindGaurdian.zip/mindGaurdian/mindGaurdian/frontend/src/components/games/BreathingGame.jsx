
import { useState } from "react";

export default function BreathingGame({ onClose }) {
  const [phase, setPhase] = useState("inhale");

  setTimeout(() => {
    setPhase((p) =>
      p === "inhale" ? "hold" : p === "hold" ? "exhale" : "inhale"
    );
  }, 3000);

  return (
    <div style={overlay}>
      <div style={card}>
        <h2>Breathing Bubble</h2>
        <div
          style={{
            ...bubble,
            transform: phase === "inhale" ? "scale(1.3)" : "scale(0.8)",
          }}
        />
        <p>{phase.toUpperCase()}</p>
        <button style={btn} onClick={onClose}>Done</button>
      </div>
    </div>
  );
}

const overlay = {
  position: "fixed",
  inset: 0,
  background: "rgba(0,0,0,.6)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
};

const card = {
  background: "#fff",
  padding: 30,
  borderRadius: 24,
  textAlign: "center",
  width: 280,
};

const bubble = {
  width: 120,
  height: 120,
  borderRadius: "50%",
  background: "#5DB075",
  margin: "20px auto",
  transition: "all 3s ease",
};

const btn = {
  padding: 12,
  borderRadius: 12,
  border: "none",
  background: "#5DB075",
  color: "#fff",
};
